﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using RestSharp;

 namespace CxApiCsharp
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // 源代码压缩包路径
            const string sourceCodePath = @"";
            
            
            var cx = new CxRestClient();
            
            
            //创建分支项目
            Console.WriteLine("1. CreateBranchedProject");
            var project = cx.CreateBranchedProject(20009, "helloWorld01");
            
            // TODO： 这里睡眠 10s 等待项目创建完成，应该使用轮询查找项目是否创建成功
            Thread.Sleep(10000);
            
            
            // 上传代码
            Console.WriteLine("2. UploadSourceCodeZipFile");
            cx.UploadSourceCodeZipFile(project.Id, sourceCodePath);
            // cx.UploadSourceCodeZipFile(30032, sourceCodePath);
            
            
            // 创建扫描
            Console.WriteLine("3. CreateNewScan");
            var scan = cx.CreateNewScan(project.Id);
            // var scan = cx.CreateNewScan(30032);
            Console.WriteLine("    Waiting for CxSAST scan finished...");
            
            while (!cx.GetScanQueueDetailsByScanId(scan.Id).Stage.Value.Equals("Finished"))
            {
                Thread.Sleep(10000);
                // Console.WriteLine(cx.GetScanQueueDetailsByScanId(scan.Id));
                // Console.WriteLine("======================================");
                
            }
            
            // 注册扫描报告
            Console.WriteLine("4. RegisterScanReport");
            // var report = cx.RegisterScanReport(1060055);
            var report = cx.RegisterScanReport(scan.Id);
            
            while (!cx.GetReportStatusById(report.ReportId).Status.Value.Equals("Created"))
            {
                Thread.Sleep(1000);
                // Console.WriteLine(cx.GetReportStatusbyId(report.ReportId));
            }
            
            // 获取报告
            Console.WriteLine("5. GetReport");
            cx.GetReport(report.ReportId, cx.GetReportStatusById(report.ReportId).ContentType);
            

        }
    }

    internal class CxRestClient
    {
        // TODO: 配置文件
        private const string BaseUrl = "http://192.168.40.7";
        private const string User = "admin";
        private const string Password = "Password01.";

        
        private string _token;
        private RestClient _client;
        public CxRestClient()
        {
            _client = new RestClient(BaseUrl);
            _token = GetAccessToken();
        }

        /*
         *  请求 AccessToken
         *  Parameters：
         *     
         *  Return：
         *     string - 拼接好的 token (Bearer <access_token>)
         */
        private string GetAccessToken()
        {
            const string uri = "/cxrestapi/auth/identity/connect/token";
            // 创建 RestRequest
            var request = new RestRequest(uri, Method.POST, DataFormat.Json);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            var requestBody = new AuthRequest(User, Password);
            request.AddParameter("username", requestBody.Username);
            request.AddParameter("password", requestBody.Password);
            request.AddParameter("grant_type", requestBody.GrantType);
            request.AddParameter("scope", requestBody.Scope);
            request.AddParameter("client_id", requestBody.ClientId);
            request.AddParameter("client_secret", requestBody.ClientSecret);
            var response = _client.Execute(request);
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception(response.Content);
            }

            //Console.WriteLine(response.Content);

            var authResponse = JsonSerializer.Deserialize<AuthResponse>(response.Content);

            return authResponse.GetAuthHeaders();
        }

        /*
         *  创建分支项目
         *  Args：
         *     int projectId - 主项目 ID
         *     string branchProjectName - 分支项目名称
         *  Returns：
         *     CreatResponse - 拼接好的 token (Bearer <access_token>)
         */
        public CreatResponse CreateBranchedProject(int projectId, string branchedProjectName)
        {
            var uri = $"/cxrestapi/projects/{projectId}/branch";
            
            var request = new RestRequest(uri, Method.POST, DataFormat.Json);
            // TODO: 公共 Header
            // request.AddHeader("Content-Type", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
            request.AddHeader("cxOrigin", "CSharp Client");

            request.AddParameter("name", branchedProjectName);
            
            var response = _client.Execute(request);
            if (response.StatusCode != HttpStatusCode.Created)
            {
                throw new Exception(response.Content);
            }

            return JsonSerializer.Deserialize<CreatResponse>(response.Content);
        }
        
        /*
         * 上传本地源代码 zip 压缩包
         * Args：
         *     int projectId - 项目 id
         *     string sourceCodeZipPath - 源代码压缩包路径(本地)
         * Returns:
         */
        public void UploadSourceCodeZipFile(int projectId, string sourceCodeZipPath)
        {
            var uri = $"/cxrestapi/projects/{projectId}/sourceCode/attachments";
            var request = new RestRequest(uri, Method.POST, DataFormat.Json);
            // TODO: 公共 Header
            // request.AddHeader("Content-Type", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
            request.AddHeader("cxOrigin", "CSharp Client");
            request.AddFileBytes("zippedSource", File.ReadAllBytes(sourceCodeZipPath),
                Path.GetFileName(sourceCodeZipPath), "application/zip");

            var response = _client.Execute(request);

            Console.WriteLine("2、"+response.ResponseStatus);
            if (response.StatusCode != HttpStatusCode.NoContent)
            {
                throw new Exception(response.Content);
            }
        }

        /*
         * 创建新的扫描
         * Args：
         *     int projectId - 项目 id
         *     bool isIncremental - 是否创建增量扫描，default：false
         *     bool isPublic - 是否公开扫描记录，default：true
         *     bool forceScan - 是否强制进行扫描，default：true
         *     string comment - 扫描备注，default：null
         * Returns:
         *     CreatResponse Object
         */
        public CreatResponse CreateNewScan(int projectId, bool isIncremental = false, bool isPublic = true,
            bool forceScan = true, string comment = null)
        {
            const string uri = "/cxrestapi/sast/scans";
            
            var request = new RestRequest(uri, Method.POST, DataFormat.Json);
            // TODO: 公共 Header
            //request.AddHeader("Content-Type", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
            //request.AddHeader("cxOrigin", "CSharp Client");

            request.AddParameter("projectId", projectId);
            request.AddParameter("isIncremental", isIncremental);
            request.AddParameter("isPublic", isPublic);
            request.AddParameter("forceScan", forceScan);
            //request.AddParameter("comment", comment);
            
            var response = _client.Execute(request);

            Console.WriteLine("3、"+response.StatusCode);
            if (response.StatusCode != HttpStatusCode.Created)
            {
                throw new Exception(response.Content);
            }

            return JsonSerializer.Deserialize<CreatResponse>(response.Content);
        }

        /*
         * 通过 ScanId 获取扫描队列状态
         * Args:
         *     int scanId - 扫描 Id
         * Returns:
         *     ScanQueueDetails Object
         */
        public ScanQueueDetails GetScanQueueDetailsByScanId(int scanId)
        {
            var uri = $"/cxrestapi/sast/scansQueue/{scanId}";
            
            var request = new RestRequest(uri, Method.GET, DataFormat.Json);
            // TODO: 公共 Header
            request.AddHeader("Accept", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);

            var response = _client.Execute(request);
            
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception(response.Content);
            }


            return JsonSerializer.Deserialize<ScanQueueDetails>(response.Content);
        }
        
        
        /*
         * 注册扫描报告
         * Args:
         *     int scanId - 扫描 Id
         *     string type - 希望生成的扫描报告类型(pdf、xml、csv、rtf) default:pdf
         * Returns:
         *     RegisterScanReportResponse Object
         */
        public RegisterScanReportResponse RegisterScanReport(int scanId, string reportType = "PDF")
        {
            const string uri = "/cxrestapi/reports/sastScan";
            
            var request = new RestRequest(uri, Method.POST, DataFormat.Json);
            // TODO: 公共 Header
            // request.AddHeader("Content-Type", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
            request.AddHeader("cxOrigin", "CSharp Client");

            request.AddParameter("scanId", scanId);
            request.AddParameter("reportType", reportType);
            
            var response = _client.Execute(request);
            if (response.StatusCode != HttpStatusCode.Accepted)
            {
                throw new Exception(response.Content);
            }

            return JsonSerializer.Deserialize<RegisterScanReportResponse>(response.Content);
        }
        
        /*
         * 获取报告生成状态
         * Args：
         *     int reportId - 扫描报告 Id
         * Returns：
         *     ReportStatus Object
         */
        public ReportStatus GetReportStatusById(int reportId)
        {
            var uri = $"/cxrestapi/reports/sastScan/{reportId}/status";
        
            var request = new RestRequest(uri, Method.GET, DataFormat.Json);
            // TODO: 公共 Header
            request.AddHeader("Accept", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
        
            var response = _client.Execute(request);
        
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception(response.Content);
            }
        
            return JsonSerializer.Deserialize<ReportStatus>(response.Content);
        }

        /*
         * 获取报告
         * Args：
         *     int reportId - 扫描报告 Id
         *     string contentType - 响应格式(application/rtf, application/xml, application/pdf, application/csv. 可根据GetReportStatusById获取)
         *     string fileName - 生成报告的路径/名称(不需要后缀)
         * Returns：
         *     
         */
        public void GetReport(int reportId, string contentType, string fileName="report")
        {
            var uri = $"/cxrestapi/reports/sastScan/{reportId}";
        
            var request = new RestRequest(uri, Method.GET, DataFormat.Json);
            // TODO: 公共 Header
            request.AddHeader("Accept", "application/json;v=1.0");
            request.AddHeader("Authorization", _token);
            request.AddHeader("Content-Type", contentType);
        
            var response = _client.Execute(request);
        
            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception(response.Content);
            }

            try
            {
                using var fs = new FileStream($"{fileName}.{contentType.Split("/")[1]}", FileMode.Create, FileAccess.Write);
                fs.Write(response.RawBytes, 0, response.RawBytes.Length);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in process: {0}", ex);
            }

        }
        
        
        
        // TODO: 单独 dto 文件
        class AuthRequest
        {
            public AuthRequest(string username, string password, string grantType = "password", 
                string scope = "sast_rest_api", string clientId = "resource_owner_client", 
                string clientSecret = "014DF517-39D1-4453-B7B3-9930C563627C")
            {
                Username = username ?? throw new ArgumentNullException(nameof(username));
                Password = password ?? throw new ArgumentNullException(nameof(password));
                GrantType = grantType;
                Scope = scope;
                ClientId = clientId;
                ClientSecret = clientSecret;
            }

            public string Username { get; set; }
            public string Password { get; set; }
            public string GrantType { get; set; }
            public string Scope { get; set; }
            public string ClientId { get; set; }
            public string ClientSecret { get; set; }

            public override string ToString()
            {
                return $"CxAuthRequest(username={Username}, password={Password}, grant_type={GrantType}, scope={Scope}, client_id={ClientId}, client_secret={ClientSecret})";
            }
        }
        // TODO: 单独 dto 文件
        class AuthResponse
        {
            [JsonPropertyName("access_token")]
            public string AccessToken { get; set; }
            [JsonPropertyName("expires_in")] 
            public int ExpiresIn { get; set; }
            [JsonPropertyName("token_type")] 
            public string TokenType { get; set; }

            public string GetAuthHeaders()
            {
                return $"{TokenType} {AccessToken}";
            }

            public override string ToString()
            {
                return $"CxAuthResponse(access_token={AccessToken}, expires_in={ExpiresIn}, token_type={TokenType})";
            }
        }

        internal class CreatResponse
        {
            [JsonPropertyName("id")] 
            public int Id { get; set; }
            
            [JsonPropertyName("link")] 
            public LinkClass Link { get; set; }

            public override string ToString()
            {
                return $"CreatResponse(id={Id},link={Link})";
            }
        }

        internal class ScanQueueDetails
        {
            [JsonPropertyName("id")]
            public int Id { get; set; }
            [JsonPropertyName("stage")]
            public StageClass Stage { get; set; }
            [JsonPropertyName("stageDetails")]
            public string StageDetails { get; set; }
            [JsonPropertyName("stepDetails")]
            public string StepDetails { get; set; }
            [JsonPropertyName("project")]
            public ProjectClass Project { get; set; }
            [JsonPropertyName("engine")]
            public EngineClass Engine { get; set; }
            [JsonPropertyName("languages")]
            public List<LanguagesClass> Language { get; set; }
            [JsonPropertyName("teamId")]
            public string TeamId { get; set; }
            [JsonPropertyName("dateCreated")]
            public string DataCreated { get; set; }
            [JsonPropertyName("queuedOn")]
            public string QueuedOn { get; set; }
            [JsonPropertyName("engineStartedOn")]
            public string EngineStartedOn { get; set; }
            [JsonPropertyName("completedOn")]
            public string CompletedOn { get; set; }
            [JsonPropertyName("loc")]
            public int Loc { get; set; }
            [JsonPropertyName("isIncremental")]
            public bool IsIncremental { get; set; }
            [JsonPropertyName("isPublic")]
            public bool IsPublic { get; set; }
            [JsonPropertyName("origin")]
            public string Origin { get; set; }
            [JsonPropertyName("queuePosition")]
            public int QueuePosition { get; set; } 
            [JsonPropertyName("totalPercent")]
            public int TotalPercent { get; set; }
            [JsonPropertyName("stagePercent")]
            public int StagePercent { get; set; } 
            [JsonPropertyName("initiator")]
            public string Initiator { get; set; } 
            
            
            internal class StageClass
            {
                [JsonPropertyName("id")]
                public int Id { get; set; }
                [JsonPropertyName("value")]
                public string Value { get; set; }

                public override string ToString()
                {
                    return $"(id={Id}, value={Value})";
                }
            }

            internal class ProjectClass
            {
                [JsonPropertyName("id")]
                public int Id { get; set; }
                [JsonPropertyName("name")]
                public string Name { get; set; }
                [JsonPropertyName("link")] 
                public LinkClass Link { get; set; }

                public override string ToString()
                {
                    return $"(id={Id}, name={Name}, Link={Link})";
                }
            }

            public override string ToString()
            {
                return
                    $"ScanQueueDetails(id={Id}, stage={Stage}, stageDetails={StageDetails}, stepDetails={StepDetails}, " +
                    $"project={Project}, engine={Engine}, languages=({string.Join(", ", Language)}), teamId={TeamId}, dateCreated={DataCreated}, " +
                    $"queuedOn={QueuedOn}, engineStartedOn={EngineStartedOn}, completedOn={CompletedOn}, loc={Loc}, " +
                    $"isIncremental={IsIncremental}, isPublic={IsPublic}, origin={Origin}, queuePosition={QueuePosition}, " +
                    $"totalPercent={TotalPercent}, stagePercent={StagePercent}, initiator={Initiator})";
            }
        }
        
        internal class LinkClass
        {
            [JsonPropertyName("rel")]
            public string Rel { get; set; }
            [JsonPropertyName("uri")]
            public string Uri { get; set; }
            public override string ToString()
            {
                return $"(rel={Rel}, uri={Uri})";
            }
        }

        internal class EngineClass
        {
            [JsonPropertyName("id")]
            public int Id { get; set; }
            [JsonPropertyName("link")]
            public LinkClass Link { get; set; }
            public override string ToString()
            {
                return $"(id={Id}, link={Link})";
            }
        }
        
        internal class LanguagesClass
        {
            [JsonPropertyName("id")]
            public int Id { get; set; }
            [JsonPropertyName("name")]
            public string Name { get; set; }
            public override string ToString()
            {
                return $"(id={Id}, name={Name})";
            }
        }

        internal class RegisterScanReportResponse
        {
            [JsonPropertyName("reportId")]
            public int ReportId { get; set; }
            [JsonPropertyName("links")]
            public LinksClass Links { get; set; }

            internal class LinksClass
            {
                [JsonPropertyName("report")]
                public LinkClass Report { get; set; }
                [JsonPropertyName("status")]
                public LinkClass Status { get; set; }

                public override string ToString()
                {
                    return $"(report={Report}, status={Status})";
                }
            }

            public override string ToString()
            {
                return $"RegisterScanReport(reportId={ReportId}, links={Links})";
            }
        }
        
        internal class ReportStatus
        {
            [JsonPropertyName("link")]
            public LinkClass Link { get; set; }
            [JsonPropertyName("contentType")]
            public string ContentType { get; set; }
            [JsonPropertyName("status")]
            public ScanQueueDetails.StageClass Status { get; set; }

            public override string ToString()
            {
                return $"ReportStatus(link={Link}, contentType={ContentType}, status={Status})";
            }
        }
    }
    

}